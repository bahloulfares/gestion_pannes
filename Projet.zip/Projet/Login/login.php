<?php
session_start();
include('../connect/connect.php');

try {
    if (isset($_POST['connexion'])) {
        $email = $_POST["email"];
        $password = $_POST["password"];

        // Check for technicien role
        $stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE Email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($userRow && $password=== $userRow["mdp"] && $userRow["role"] === "technicien") {
            header("Location: ../sideBarTech/index.php");
            exit();
        }

        // Check for admin role
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE Email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $adminRow = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($adminRow && $password===$adminRow["mdp"]) {
            $_SESSION['admin_name'] = $adminRow['nom'];
            header("Location: ../Admin/index.php");
            exit();
        }

        throw new Exception("Identifiants incorrects. Veuillez réessayer");
    } else {
        throw new Exception("Email ou mot de passe incorrect !");
    }
} catch (Exception $e) {
    echo "<script>alert('" . $e->getMessage() . "');</script>";
    header("Refresh:0; url=login.html");
    exit();
} finally {
    $pdo = null; // Close the database connection in the finally block
}
?>

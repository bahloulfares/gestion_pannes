<?php
try{
    $user = "root";
    $pass = "";
    $pdo = new PDO("mysql:host=localhost;dbname=gestion_pannes",$user,$pass) ;
}catch(PDOException $e){
    echo $e->getMessage();
}

?>
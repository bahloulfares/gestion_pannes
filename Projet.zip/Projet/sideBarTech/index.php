<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
        <!-- <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
    <div class="d-flex" id="wrapper" >
            
        <div class="border-end " id="sidebar-wrapper" >
                <div class="sidebar-heading border-bottom bg-light" >Menu Technicien</div>
                    <div class="list-group list-group-flush">
                    <a href="ordreTravail.php" class="list-group-item list-group-item-action list-group-item-light p-3 custom-link">Liste des Interventions</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="materiel.php">Liste des materiel</a>
                        <a class="list-group-item list-group-item-action list-group-item-light p-3" href="ordreTravail.php">Liste des Intervention</a>
                        <a class="list-group-item list-group-item-action list-group-item-light p-3" href="materiel.php">Liste des materiel</a>
                        <div class="fixed-bottom" >
                            <a href="../index.html" class="btn btn-danger" style="width:240px;">Déconnexion</a>
                        </div>
                    </div>
        </div>
    </div> -->
    <style>
/* Basic Sidebar Styles */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100vh;
  width: 250px; /* Adjust width as needed */
  background-color: #f5f5f5;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease-in-out;
}

.sidebar.collapsed {
  width: 60px; /* Narrow sidebar when collapsed */
}

.sidebar-header {
  padding: 20px;
  text-align: center;
}

.sidebar-logo {
  display: inline-block;
}

.sidebar-logo img {
  width: 80px; /* Adjust logo size */
  height: auto;
}

.sidebar-nav {
  padding: 0; /* Remove default padding */
  list-style: none;
}

.nav-item {
  margin-bottom: 10px;
}

.nav-link {
  display: flex;
  align-items: center;
  padding: 10px 20px;
  color: #333;
  text-decoration: none; /* Remove underline */
  transition: all 0.3s ease-in-out;
}

.nav-link:hover {
  background-color: #e9ecef; /* Light hover effect */
}

.nav-link.active {
  background-color: #ddd; /* Highlight active link */
}

.nav-link i {
  margin-right: 10px; /* Spacing between icon and text */
  font-size: 18px; /* Adjust icon size */
}

.nav-link span {
  font-weight: bold; /* Make link text bolder */
}

/* Dropdown Menu Styles */
.dropdown-menu {
  background-color: #f5f5f5;
  border-radius: 0; /* Remove default border radius */
}

.dropdown-item {
  padding: 10px 20px;
  color: #333;
  transition: all 0.3s ease-in-out;
}

.dropdown-item:hover {
  background-color: #e9ecef; /* Light hover effect */
}

    </style>
   <div class="sidebar">
  <div class="sidebar-header">
   <h5>Menu Technicien</h5>
  </div>
  <hr>
  <nav class="sidebar-nav">
    <ul>
      <li class="nav-item">
        <a href="ordreTravail.php" class="nav-link">
          <i class="fas fa-home"></i>
          <span>Liste des Interventions</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="materiel.php" class="nav-link">
          <i class="fas fa-home"></i>
          <span>Liste des materiel</span>
        </a>
      </li>
      </ul>
        <div class="fixed-bottom" >
            <a href="../index.html" class="btn btn-danger" style="width:250px;">Déconnexion</a>
        </div>
  </nav>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des materiel</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body><style>
#a {
  float: left;
}
 
#b {
  float: right;
  padding-right:100px;
}
</style>
<body>
<div id="a">
    <?php include "index.php";?>
</div>
<div id="b" class="container">
    <center><h2>Liste des materiel</h2></center><br><br>

    <table class="table table-bordered table-striped">
            <thead class="thead-dark">
            <tr>
                <th>ID Materiel</th>
                <th>Produit</th>
                <th>Marque</th>
                <th>Model</th>
                <th>Numéro de Serie</th>
                <th>Date mise en service</th>
                <th>Service</th>
                <th>Statut</th>
                <th>ID utilisatuer</th>
                <th>Nom</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Connexion à la base de données (à remplacer avec vos propres informations)
            include('../connect/connect.php');
            
            // Requête pour récupérer les utilisateurs
            $result = $pdo->query("SELECT * FROM materiel");
            $reslt = $pdo->query("SELECT * FROM utilisateur");

            // Afficher les utilisateurs dans le tableau
            while ($materiel = $result->fetch(PDO::FETCH_ASSOC)) {
                $user = $reslt->fetch(PDO::FETCH_ASSOC);
                echo "<tr>";
                echo "<td>" . $materiel['ID_Materiel'] . "</td>";
                echo "<td>" . $materiel['Produit'] . "</td>";
                echo "<td>" . $materiel['Marque'] . "</td>";
                echo "<td>" . $materiel['model'] . "</td>";
                echo "<td>" . $materiel['NumSerie'] . "</td>";
                echo "<td>" . $materiel['DateMES'] . "</td>";
                echo "<td>" . $materiel['Service'] . "</td>";
                echo "<td>" . $materiel['Statut'] . "</td>";
                echo "<td>" . $materiel['ID_Utilisateur'] . "</td>";
                echo "<td>" . $user['nom'] . "</td>";
                echo "</tr>";
            }
            // Fermer la connexion à la base de données
            $pdo = null;
            ?>
        </tbody>
    </table>
</div>

<!-- Ajoutez le lien vers le fichier JavaScript Bootstrap (optionnel) -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

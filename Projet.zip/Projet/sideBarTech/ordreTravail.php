<?php
ob_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
session_start();
include "../connect/connect.php";

$interventions = array();

try {
    // Requête pour récupérer toutes les interventions
    $query = "SELECT I.*, U.nom, U.prenom, M.Marque, M.model FROM Intervention I
              JOIN Utilisateur U ON I.ID_Utilisateur = U.ID_Utilisateur
              JOIN Materiel M ON I.ID_Materiel = M.ID_Materiel";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    // Stocker les résultats dans un tableau associatif
    $interventions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // En cas d'erreur PDO, affichez l'erreur
    echo "Erreur de connexion à la base de données: " . $e->getMessage();
}

if (isset($_POST['reparer'])) {
    // Display the repair form
    if (isset($_POST['intervention_id'])) {
        $intervention_id = $_POST['intervention_id'];
        $utilisateur_id = $_POST['utilisateur_id'];
        $id_materiel = $_POST['id_materiel'];

        $htmlContent ="<!DOCTYPE html>
        <html lang=\"en\">
        <head>
            <meta charset=\"UTF-8\">
            <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
            <title>Document</title>
            <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">
           
        </head>
        <body style=\"margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;\"
                >
            <form method='post' action='" . $_SERVER['PHP_SELF'] . "' 
                    class='repair-form' style=\" padding: 20px;
                    border-radius: 8px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    max-width: 400px;
                    width: 100%;\">
                <fieldset>
                    <legend class=\"mb-4\">Ordre de travail</legend>
                
                    <div class=\"form-group\">
                            <input type='hidden' name='intervention_id' value='$intervention_id'>
                            <input type='hidden' name='utilisateur_id' value='$utilisateur_id'>
                            <input type='hidden' name='id_materiel' value='$id_materiel'>
                
                            <label for='date_debut' class=\"mb-2\">Date de Début:</label>
                            <input type='date' name='date_debut' class=\"form-control\" required>
                
                            <label for='date_cloture' class=\"mb-2\">Date de Clôture:</label>
                            <input type='date' name='date_cloture' class=\"form-control\">
                
                            <label for='date_reparation' class=\"mb-2\">Date de Réparation:</label>
                            <input type='date' name='date_reparation' class=\"form-control\">
                
                            <label for='nature_travaux' class=\"mb-2\">Nature des Travaux:</label>
                            <input type='text' name='nature_travaux' class=\"form-control\" required>
                
                            <label for='observation' class=\"mb-2\">Observation:</label>
                            <textarea name='observation' class=\"form-control\"></textarea>
                            <label for=\"status\">Statut du matériel</label>
                            <select name=\"status\" id=\"status\" class=\"form-control\">
                                <option value=\"irréparable\">irréparable</option>
                                <option value=\"En marche\">En marche</option>
                            </select>
                            <input type='submit' name='confirm_repair' value='Confirmer la Réparation' class=\"btn btn-primary mt-3\">
                            <a href=\"index.php\" class=\"btn btn-primary mt-3\" style=\"background-color:gray;border:none;margin-left:30px\">Annuler</a>
                            </div>
                            
            </fieldset>
        </form>
    </body>
    </html>";
    echo $htmlContent;
        exit();
    } else {
        echo "<script>alert('Error: Intervention ID not provided');</script>";
    }
} elseif (isset($_POST['confirm_repair'])) {
    // Handle the confirmed repair action
    if (isset($_POST['intervention_id']) && isset($_POST['utilisateur_id']) && isset($_POST['id_materiel'])) {
        $intervention_id = $_POST['intervention_id'];
        $id_materiel = $_POST['id_materiel'];
        $id_utilisateur = $_POST['utilisateur_id'];
        // Implement your logic here for confirming the repair
        // Retrieve data from the form
        $date_debut = $_POST['date_debut'];
        $date_cloture = $_POST['date_cloture'];
        $date_reparation = $_POST['date_reparation'];
        $nature_travaux = $_POST['nature_travaux'];
        $observation = $_POST['observation'];
        $selectedStatus = $_POST['status'];
        // Now you can insert this data into your 'ordretravail' table
        // Use prepared statements to avoid SQL injection
        $insert_query = "INSERT INTO ordretravail (DateDebut_OT, DateDeCloture, DateReparation, NatureTravaux, Observation, ID_Materiel, ID_Utilisateur, ID_Intervention)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $insert_stmt = $pdo->prepare($insert_query);
        $insert_stmt->execute([$date_debut, $date_cloture, $date_reparation, $nature_travaux, $observation, $id_materiel, $id_utilisateur, $intervention_id]);
        //Update Statut
        if($insert_stmt){
        $updateQuery = "UPDATE materiel SET Statut = :status WHERE ID_Materiel = :idMateriel";
        $updateStmt = $pdo->prepare($updateQuery);
        $updateStmt->bindParam(':status', $selectedStatus, PDO::PARAM_STR);
        $updateStmt->bindParam(':idMateriel', $id_materiel, PDO::PARAM_INT);
        $updateStmt->execute();
        }
        $mail = new PHPMailer(true);
        $mailUser = "SELECT Email FROM utilisateur WHERE ID_Utilisateur = :iduser";
        $upStmt = $pdo->prepare($mailUser);
        $upStmt->bindParam(':iduser', $id_utilisateur, PDO::PARAM_INT);
        $upStmt->execute();
        
        $emailAddress = $upStmt->fetchColumn();

        $nomUser = "SELECT nom FROM utilisateur WHERE ID_Utilisateur = :iduser";
        $nomStmt = $pdo->prepare($nomUser);
        $nomStmt->bindParam(':iduser', $id_utilisateur, PDO::PARAM_INT);
        $nomStmt->execute();

        $nomUtilisateur = $nomStmt->fetchColumn();
                
           try{
            //Server settings
            $mail->SMTPDebug = 2;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'bahloulfares100@gmail.com';
            $mail->Password = 'iykn zxoj ngbq wakg';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 25;

            //Recipients
            $mail->setFrom('bahloulfares100@gmail.com');
            $mail->addAddress($emailAddress);

            $body = '<p>Cher(e) '.$nomUtilisateur.',</p>

            <p>Nous sommes heureux de vous informer que la réparation du matériel a été réalisée avec succès. Notre équipe technique a travaillé ardemment pour résoudre les problèmes signalés, et nous nous attendons à ce que votre équipement retrouve désormais ses performances optimales.</p>
        
            <p>La clôture de l\'intervention a eu lieu le ['.$date_reparation.'], et toutes les vérifications nécessaires ont été effectuées pour garantir le bon fonctionnement de l\'équipement. Si vous avez besoin d\'une assistance supplémentaire ou si vous avez des questions, n\'hésitez pas à nous contacter.</p>
        
            <p>Nous vous remercions pour votre compréhension et votre coopération tout au long de ce processus. Nous apprécions votre engagement à faire de [Nom de la société] un endroit exceptionnel pour travailler.</p>
        
            <p>Cordialement,<br>
                [Fares]<br>
                [Responsable Technique]<br>
                [Société GPMI]<br>
                [+216 12345678]</p>';

            //Content
            $mail->isHTML(true);
            $mail->Subject = 'Message de Réparation';

            $mail->Body = $body;
            $mail->AltBody = strip_tags($body);

            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';

            $mail->send();
            echo "<script>alert('Message envoyé avec succès');</script>";
            header("Refresh:0; url=index.php");
           }catch(Exception $e){
            echo "<script>alert('Le message n\'a pas pu être envoyé\n Mailer Error:'.$mail->ErrorInfo');</script>";
           }
        echo "<script>alert('La réparation pour l\'intervention d\'ID $intervention_id a été confirmée et ajoutée à la table ordretravail.');</script>";
    } else {
        echo "<script>alert('Error: Intervention ID not provided.');</script>";
    }
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau des interventions</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
    #a  {
  float: left;
}
 
#container{
  float: right;
  padding-right:100px
  
}
</style>
<body>
<div id="a" >
    <?php include "index.php";?>
    </div><br><br>
    <div class="container" id="container">
        <center><h1>Liste des interventions</h1></center><br>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-inline mb-3">
            <label class="mr-2" for="Statut_materiel">Filtrer par statut :</label>
            <select name="Statut_materiel" id="Statut_materiel" class="form-control mr-2">
                <option value="tous">Tous</option>
                <option value="non_repare">Non réparé</option>
                <option value="repare">Réparé</option>
            </select>
            <input type="submit" class="btn btn-primary" name="filter" value="Filtrer">
        </form>

        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID Intervention</th>
                    <th>Date de Déclaration</th>
                    <th>Description</th>
                    <th>ID Utilisateur</th>
                    <th>Nom Utilisateur</th>
                    <th>ID Matériel</th>
                    <th>Marque</th>
                    <th>Modèle</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
                if (isset($_POST['filter'])) {
                    $Statut = $_POST['Statut_materiel'];
                    foreach ($interventions as $intervention) {
                        if ($Statut === 'tous') {
                            $idMateriel = $intervention['ID_Materiel'];
                            $statutMateriel = "";
                        
                            // Requête pour récupérer le statut du matériel
                            $queryStatut = "SELECT Statut FROM materiel WHERE ID_Materiel = ?";
                            $stmtStatut = $pdo->prepare($queryStatut);
                            $stmtStatut->execute([$idMateriel]);
                            $resultStatut = $stmtStatut->fetch(PDO::FETCH_ASSOC);
                            
                            //verifier si exeist au tableau ordreTravail
                            $idIntervention = $intervention['ID_Intervention'];
                            $stmtCheckID = $pdo->prepare("SELECT * FROM ordretravail WHERE ID_Intervention = ?");
                            $stmtCheckID->execute([$idIntervention]);
                            $idExists = $stmtCheckID->fetchColumn();                                    

                        
                            
                            $statutMateriel = $resultStatut['Statut'];
                            echo "<tr>
                            <td>" . $intervention['ID_Intervention'] . "</td>
                            <td>" . $intervention['DateDeclaration'] . "</td>
                            <td>" . $intervention['Description'] . "</td>
                            <td>" . $intervention['ID_Utilisateur'] . "</td>
                            <td>" . $intervention['nom'] . ' ' . $intervention['prenom'] . "</td>
                            <td>" . $intervention['ID_Materiel'] . "</td>
                            <td>" . $intervention['Marque'] . "</td>
                            <td>" . $intervention['model'] . "</td>
                            <td>
                                <form method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\">
                                    <input type=\"hidden\" name=\"intervention_id\" value=\"" . $intervention['ID_Intervention'] . "\">
                                    <input type=\"hidden\" name=\"utilisateur_id\" value=\"" . $intervention['ID_Utilisateur'] . "\">
                                    <input type=\"hidden\" name=\"id_materiel\" value=\"" . $intervention['ID_Materiel'] . "\">";

                                if ($statutMateriel === 'En cours de réparation' && !$idExists) {
                                    echo "<p><input type=\"submit\" class=\"btn btn-primary\" name=\"reparer\" value=\"Réparer\"></p>";
                                } elseif ($statutMateriel === 'En marche' && $idExists) {
                                        echo "<p><input type=\"submit\" class=\"btn btn-primary\" name=\"reparer\" value=\"Réparer\" disabled></p>";                                    
                                   }elseif ($statutMateriel === 'irréparable'&& $idExists) {
                                        echo "<p style=\"color:red;\"><b>irréparable</b></p>";
                                    }            

                                echo "</form>
                                    </td>
                                </tr>";
                    
                        } elseif ($Statut === 'non_repare') {
                                    $idMateriel = $intervention['ID_Materiel'];
                                    $statutMateriel = "";
                                
                                    // Requête pour récupérer le statut du matériel
                                    $queryStatut = "SELECT Statut FROM materiel WHERE ID_Materiel = ?";
                                    $stmtStatut = $pdo->prepare($queryStatut);
                                    $stmtStatut->execute([$idMateriel]);
                                    $resultStatut = $stmtStatut->fetch(PDO::FETCH_ASSOC);
                                    
                                    //verifier si exeist au tableau ordreTravail
                                    $idIntervention = $intervention['ID_Intervention'];
                                    $stmtCheckID = $pdo->prepare("SELECT * FROM ordretravail WHERE ID_Intervention = ?");
                                    $stmtCheckID->execute([$idIntervention]);
                                    $idExists = $stmtCheckID->fetchColumn();                             
        
                                
                                    
                                    $statutMateriel = $resultStatut['Statut'];
                                     if ($statutMateriel === 'En cours de réparation'&& !$idExists) {
                                        echo "<tr>
                                        <td>" . $intervention['ID_Intervention'] . "</td>
                                        <td>" . $intervention['DateDeclaration'] . "</td>
                                        <td>" . $intervention['Description'] . "</td>
                                        <td>" . $intervention['ID_Utilisateur'] . "</td>
                                        <td>" . $intervention['nom'] . ' ' . $intervention['prenom'] . "</td>
                                        <td>" . $intervention['ID_Materiel'] . "</td>
                                        <td>" . $intervention['Marque'] . "</td>
                                        <td>" . $intervention['model'] . "</td>
                                        <td>
                                            <form method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\">
                                                <input type=\"hidden\" name=\"intervention_id\" value=\"" . $intervention['ID_Intervention'] . "\">
                                                <input type=\"hidden\" name=\"utilisateur_id\" value=\"" . $intervention['ID_Utilisateur'] . "\">
                                                <input type=\"hidden\" name=\"id_materiel\" value=\"" . $intervention['ID_Materiel'] . "\">";
            
                                        
                                                echo "<p><input type=\"submit\" class=\"btn btn-primary\" name=\"reparer\" value=\"Réparer\"></p>";                                           
                                            echo "</form>
                                                </td>
                                            </tr>";  
                                    }          
                                    
                    }elseif ($Statut === 'repare') {
                        $idMateriel = $intervention['ID_Materiel'];
                            $statutMateriel = "";
                        
                            // Requête pour récupérer le statut du matériel
                            $queryStatut = "SELECT Statut FROM materiel WHERE ID_Materiel = ?";
                            $stmtStatut = $pdo->prepare($queryStatut);
                            $stmtStatut->execute([$idMateriel]);
                            $resultStatut = $stmtStatut->fetch(PDO::FETCH_ASSOC);
                            
                            //verifier si exeist au tableau ordreTravail
                            $idIntervention = $intervention['ID_Intervention'];
                            $stmtCheckID = $pdo->prepare("SELECT * FROM ordretravail WHERE ID_Intervention = ?");
                            $stmtCheckID->execute([$idIntervention]);
                            $idExists = $stmtCheckID->fetchColumn();                                    

                        
                            
                            $statutMateriel = $resultStatut['Statut'];
                            if ($statutMateriel === 'En marche' && $idExists) {
                                echo "<tr>
                                <td>" . $intervention['ID_Intervention'] . "</td>
                                <td>" . $intervention['DateDeclaration'] . "</td>
                                <td>" . $intervention['Description'] . "</td>
                                <td>" . $intervention['ID_Utilisateur'] . "</td>
                                <td>" . $intervention['nom'] . ' ' . $intervention['prenom'] . "</td>
                                <td>" . $intervention['ID_Materiel'] . "</td>
                                <td>" . $intervention['Marque'] . "</td>
                                <td>" . $intervention['model'] . "</td>
                                <td>
                                    <form method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\">
                                        <input type=\"hidden\" name=\"intervention_id\" value=\"" . $intervention['ID_Intervention'] . "\">
                                        <input type=\"hidden\" name=\"utilisateur_id\" value=\"" . $intervention['ID_Utilisateur'] . "\">
                                        <input type=\"hidden\" name=\"id_materiel\" value=\"" . $intervention['ID_Materiel'] . "\">";
                                
                                            echo "<p><input type=\"submit\" class=\"btn btn-primary\" name=\"reparer\" value=\"Réparer\" disabled></p>";
                                    

                                    echo "</form>
                                        </td>
                                    </tr>";
                            }elseif ($statutMateriel === 'irréparable' && $idExists) {
                                echo "<tr>
                                <td>" . $intervention['ID_Intervention'] . "</td>
                                <td>" . $intervention['DateDeclaration'] . "</td>
                                <td>" . $intervention['Description'] . "</td>
                                <td>" . $intervention['ID_Utilisateur'] . "</td>
                                <td>" . $intervention['nom'] . ' ' . $intervention['prenom'] . "</td>
                                <td>" . $intervention['ID_Materiel'] . "</td>
                                <td>" . $intervention['Marque'] . "</td>
                                <td>" . $intervention['model'] . "</td>
                                <td>
                                    <form method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\">
                                        <input type=\"hidden\" name=\"intervention_id\" value=\"" . $intervention['ID_Intervention'] . "\">
                                        <input type=\"hidden\" name=\"utilisateur_id\" value=\"" . $intervention['ID_Utilisateur'] . "\">
                                        <input type=\"hidden\" name=\"id_materiel\" value=\"" . $intervention['ID_Materiel'] . "\">";
                                        
                                        echo "<p style=\"color:red;\"><b>irréparable</b></p>";                                        
                                    echo "</form>
                                        </td>
                                    </tr>";  
                            }            
                    }
                    
                }
            }
                ?>
            </tbody>
        </table>
        <a href="technicien.php" class="btn btn-primary">Ajouter</a>
    </div>
</body>

</html>
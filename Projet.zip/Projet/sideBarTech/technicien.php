<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Ajouter une demande</title>
  <link rel="stylesheet" href="styleTech.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style>
#a {
  float: left;
}
 
#b {
  float: right;
  padding-right:100px;
}
</style>
<body>
<div id="a">
    <?php include "index.php";?>
</div>
  <div id="b"><br><br>
  <center> <h1>Ajouter Intervention</h1></center>
  <form action="" method="post">
    <div class="form-group">
      <label for="numero-demande">Serie Materiel</label>
      <input type="number" name="SM" id="numero-demande" class="form-control">
      <button type="submit" name="recherche" id="recherche" class="btn btn-primary">Recherche</button>

    </div>
    <?php
    include "../connect/connect.php";

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recherche'])) {
  $serieMachine = $_POST['SM'];
  $sql = "SELECT * FROM materiel WHERE NumSerie = :SM";

  $stmt = $pdo->prepare($sql);
  $stmt->bindParam(':SM', $serieMachine);
  
  $stmt->execute();
  
  $result = $stmt->fetch(PDO::FETCH_ASSOC);
  
  if($result){
    // Display the details in a table
    echo '<table border="1">';
    echo '<tr><th>ID_Materiel</th><th>Produit</th><th>Marque</th><th>Model</th><th>NumSerie</th><th>DateMES</th><th>Service</th><th>Statut</th><th>ID_Utilisateur</th></tr>';
    echo '<tr>';
    echo '<td>'.$result['ID_Materiel'].'</td>';
    echo '<td>'.$result['Produit'].'</td>';
    echo '<td>'.$result['Marque'].'</td>';
    echo '<td>'.$result['model'].'</td>';
    echo '<td>'.$result['NumSerie'].'</td>';
    echo '<td>'.$result['DateMES'].'</td>';
    echo '<td>'.$result['Service'].'</td>';
    echo '<td>'.$result['Statut'].'</td>';
    echo '<td>'.$result['ID_Utilisateur'].'</td>';
    echo '</tr>';
    echo '</table>'; 
  } else {
    echo '<p style="color: red; font-weight: bold;">Matériel non trouvé</p>';
  }
}
if (isset($_POST["valider"])) {
  $dateDeclaration = $_POST['dd'];
  $description = $_POST['desc'];

  // Assurez-vous que les variables ID_Utilisateur et ID_Materiel sont définies
  if (isset($_POST['idUtilisateur']) && isset($_POST['idMateriel'])) {
      $idUtilisateur = $_POST['idUtilisateur'];
      $idMateriel = $_POST['idMateriel'];
      $selectedStatus = $_POST['status'];

      $x = $pdo->prepare("SELECT * FROM materiel WHERE ID_Materiel = :idMateriel");
      $x->bindParam(':idMateriel', $idMateriel, PDO::PARAM_INT);
      $x->execute();
      $m = $x->fetch(PDO::FETCH_ASSOC);
      
      $sm = $m['Statut'];

      if($sm == "En cours de réparation"){
          echo "<script>alert('Erreur le materiel dega en cours de reparation.');</script>";
          header("Refresh:0; url=technicien.php");
          exit();
      }
      
      if (empty($idUtilisateur) || empty($idMateriel) || empty($dateDeclaration) || empty($description) || empty($selectedStatus)) {
          echo "<script>alert('Veuillez remplir tous les champs du formulaire!');</script>";
          header("Refresh:0; url=technicien.php"); // Redirection vers la même page après 2 secondes
          exit();
      }
      try {
          // Requête pour ajouter une intervention à la table Intervention
          $query = "INSERT INTO intervention (DateDeclaration, Description, ID_Utilisateur, ID_Materiel)
                    VALUES (:dateDeclaration, :description, :idUtilisateur, :idMateriel)";
          $stmt = $pdo->prepare($query);
          $stmt->bindParam(':dateDeclaration', $dateDeclaration, PDO::PARAM_STR);
          $stmt->bindParam(':description', $description, PDO::PARAM_STR);
          $stmt->bindParam(':idUtilisateur', $idUtilisateur, PDO::PARAM_INT);
          $stmt->bindParam(':idMateriel', $idMateriel, PDO::PARAM_INT);
          $stmt->execute();
          if($stmt){
            $updateQuery = "UPDATE materiel SET Statut = :status WHERE ID_Materiel = :idMateriel";
            $updateStmt = $pdo->prepare($updateQuery);
            $updateStmt->bindParam(':status', $selectedStatus, PDO::PARAM_STR);
            $updateStmt->bindParam(':idMateriel', $idMateriel, PDO::PARAM_INT);
            $updateStmt->execute();
          }
      } catch (PDOException $e) {
          // En cas d'erreur PDO, affichez l'erreur
          echo "Erreur de connexion à la base de données: " . $e->getMessage();
      }
  } else {

      echo "<script>alert('Erreur : ID utilisateur et/ou ID matériel manquants');</script>";
  }
  if ($stmt) {
    echo "<script>alert('L\'intervention a été ajoutée avec succès');</script>";

  }
}

?>
    <div class="form-group">
        <label for="status">Statut du matériel</label>
        <select name="status" id="status" class="form-control">
          <option value="En cours de réparation">En cours de réparation</option>
        </select>
    </div>
    <div class="form-group">
      <label for="date-declaration">Date declaration</label><br>
      <input type="date" name="dd" id="dd" class="form-control" require>
    </div>
    <div class="form-group">
      <label for="date-declaration">description</label>
      <input type="text" name="desc" id="desc" class="form-control" require>
    </div>
    <button type="submit" name="valider" class="btn btn-primary">Valider</button>
    <a href="ordreTravail.php" class="btn btn-secondary">Annuler</a>
    <br>
    <!-- Ajout des champs ID_Utilisateur et ID_Materiel -->
    <input type="hidden" name="idUtilisateur" value="<?php echo $result['ID_Utilisateur'];?>">
    <br>
    <input type="hidden" name="idMateriel" value="<?php echo $result['ID_Materiel'];  ?>">
  </form>
</div>
</body>
</html>

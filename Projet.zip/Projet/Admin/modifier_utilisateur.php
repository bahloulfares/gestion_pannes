<?php
// Connexion à la base de données (à remplacer avec vos propres informations)
include('../connect/connect.php');

// Vérifier si l'ID de l'utilisateur est passé en paramètre
if (isset($_GET['id'])) {
    $id_utilisateur = $_GET['id'];

    // Récupérer les informations de l'utilisateur
    $stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE ID_Utilisateur = ?");
    $stmt->execute([$id_utilisateur]);
    $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$utilisateur) {
        // Rediriger si l'utilisateur n'est pas trouvé
        header("Location: index.php");
        exit();
    }
} else {
    // Rediriger si l'ID de l'utilisateur n'est pas spécifié
    header("Location: index.php");
    exit();
}

// Traitement du formulaire de modification si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $numTel = $_POST['numTel'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $mdp = $_POST['password'];

    // Mettre à jour les données de l'utilisateur
    $stmt = $pdo->prepare("UPDATE utilisateur SET nom=?, prenom=?, numTel=?, role=?, Email=? ,mdp=? WHERE ID_Utilisateur=?");
    $stmt->execute([$nom, $prenom, $numTel, $role, $email, $mdp, $id_utilisateur]);

    if($stmt){
        echo "<script>alert('Modification effectué avec succées.');</script>";
    }

    // Rediriger après la modification
    header("Refresh:0; url=index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Utilisateur</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
   <center> <h2>Modifier Utilisateur</h2></center>

    <form method="post" action="">
        <div class="form-group">
            <label for="nom">Nom:</label>
            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo $utilisateur['nom']; ?>">
        </div>
        <div class="form-group">
            <label for="prenom">Prénom:</label>
            <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo $utilisateur['prenom']; ?>">
        </div>
        <div class="form-group">
            <label for="numTel">Numéro de Téléphone:</label>
            <input type="text" class="form-control" id="numTel" name="numTel" value="<?php echo $utilisateur['numTel']; ?>">
        </div>
        <div class="form-group">
            <label for="role">Rôle:</label>
            <input type="text" class="form-control" id="role" name="role" value="<?php echo $utilisateur['role']; ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $utilisateur['Email']; ?>">
        </div>
        <div class="form-group">
            <label for="password">Mot de Passe:</label>
            <input type="password" class="form-control" id="mdp" name="password" value="<?php echo $utilisateur['mdp']; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
        <a href="index.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>

<!-- Ajoutez le lien vers le fichier JavaScript Bootstrap (optionnel) -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

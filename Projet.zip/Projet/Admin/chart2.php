<!DOCTYPE HTML>
<html>

<head>
    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
    <script>
        window.onload = function () {

            // Création du graphique
            var chart = new CanvasJS.Chart("chartContainer", {
                title: {
                    text: "House Median Price"
                },
                axisX: {
                    valueFormatString: "MMM YYYY"
                },
                axisY2: {
                    title: "Median List Price",
                    prefix: "$",
                    suffix: "K"
                },
                toolTip: {
                    shared: true
                },
                legend: {
                    cursor: "pointer",
                    verticalAlign: "top",
                    horizontalAlign: "center",
                    dockInsidePlotArea: true,
                    itemclick: toggleDataSeries
                },
                data: [{
                        type: "line",
                        axisYType: "secondary",
                        name: "San Francisco",
                        showInLegend: true,
                        markerSize: 0,
                        yValueFormatString: "$#,###k",
                        dataPoints: [
                            // Données pour San Francisco
                        ]
                    },
                    {
                        type: "line",
                        axisYType: "secondary",
                        name: "Manhattan",
                        showInLegend: true,
                        markerSize: 0,
                        yValueFormatString: "$#,###k",
                        dataPoints: [
                            // Données pour Manhattan
                        ]
                    },
                    {
                        type: "line",
                        axisYType: "secondary",
                        name: "Seattle",
                        showInLegend: true,
                        markerSize: 0,
                        yValueFormatString: "$#,###k",
                        dataPoints: [
                            // Données pour Seattle
                        ]
                    },
                    {
                        type: "line",
                        axisYType: "secondary",
                        name: "Los Angeles",
                        showInLegend: true,
                        markerSize: 0,
                        yValueFormatString: "$#,###k",
                        dataPoints: [
                            // Données pour Los Angeles
                        ]
                    }
                ],
                annotations: [{
                    label: {
                        text: "Période spécifique",
                        fontFamily: "Arial",
                        fontSize: 12,
                        fontWeight: "bold",
                        borderThickness: 1,
                        backgroundColor: "rgba(255,255,255,0.7)"
                    },
                    arrow: {
                        angle: 180,
                        length: 20,
                        thickness: 2,
                    },
                    x: new Date(2015, 06, 01).getTime(), // Date de début de la période
                    y: 1000, // Valeur en Y pour placer l'annotation
                    x2: new Date(2016, 06, 01).getTime(), // Date de fin de la période
                    y2: 1400,
                }]
            });

            // Rendu du graphique
            chart.render();

            // Fonction pour basculer la visibilité des séries de données
            function toggleDataSeries(e) {
                if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                    e.dataSeries.visible = false;
                } else {
                    e.dataSeries.visible = true;
                }
                chart.render();
            }
        }
    </script>
</head>

<body>
    <div id="chartContainer" style="height: 300px; width: 100%;"></div>
</body>

</html>

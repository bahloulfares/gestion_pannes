<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Connexion à la base de données (à remplacer avec vos propres informations)
    include('../connect/connect.php');

    // Récupérer les données du formulaire
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $numTel = $_POST['numTel'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];

    // Préparer la requête d'insertion
    $stmt = $pdo->prepare("INSERT INTO utilisateur (nom, prenom, numTel, role, Email, mdp) VALUES (?, ?, ?, ?, ?, ?)");

    // Exécuter la requête avec les valeurs fournies
    $stmt->execute([$nom, $prenom, $numTel, $role, $email, $mdp]);

    // Rediriger vers la liste des utilisateurs après l'ajout
    echo "<script>alert('L\'utilisateur a été ajoutée avec succès');</script>";
    header("refresh: 0");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter Utilisateur</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-4">
       <center> <h2>Ajouter Utilisateur</h2></center>

        <form method="POST" action="">
            <div class="form-group">
                <label for="nom">Nom:</label>
                <input type="text" class="form-control" id="nom" name="nom" required>
            </div>
            <div class="form-group">
                <label for="prenom">Prénom:</label>
                <input type="text" class="form-control" id="prenom" name="prenom" required>
            </div>
            <div class="form-group">
                <label for="numTel">Numéro de Téléphone:</label>
                <input type="tel" class="form-control" id="numTel" name="numTel" required>
            </div>
            <div class="form-group">
                <label for="role">Rôle:</label>
                <select class="form-control" id="role" name="role" required>
                    <option value="technicien">Technicien</option>
                    <option value="employe">Employé</option>
                </select>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="mdp">Mot de passe:</label>
                <input type="password" class="form-control" id="mdp" name="mdp">
            </div>
            <button type="submit" class="btn btn-primary">Ajouter Utilisateur</button>
            <a href="index.php" class="btn btn-secondary">Annuler</a>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>
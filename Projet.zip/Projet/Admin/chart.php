<?php
                include('../connect/connect.php');

                $resultEnPanne = $pdo->query("SELECT COUNT(*) AS total FROM intervention WHERE ID_Materiel IN (SELECT ID_Materiel FROM materiel WHERE Statut = 'En cours de réparation')");
                $enPanne = $resultEnPanne->fetch(PDO::FETCH_ASSOC)['total'];

                $resultIrréparable = $pdo->query("SELECT COUNT(*) AS total FROM intervention WHERE ID_Materiel IN (SELECT ID_Materiel FROM materiel WHERE Statut = 'irréparable')");
                $irréparable = $resultIrréparable->fetch(PDO::FETCH_ASSOC)['total'];

                $resultRepare = $pdo->query("SELECT COUNT(*) AS total FROM intervention WHERE ID_Materiel IN (SELECT ID_Materiel FROM materiel WHERE Statut = 'En marche')");
                $repare = $resultRepare->fetch(PDO::FETCH_ASSOC)['total'];

                $pdo = null;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques de Pannes</title>
    <style>
        body {
            margin: 0;
            padding: 0;
        }

        #chart {
        width: 40vw;
        height: 60vh;
        margin: 0 auto; /* Center horizontally */
        margin-top: 50px; /* Adjust as needed */
}

    </style>
</head>
<body>
<canvas id="chart"></canvas>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>



    <script>
     jQuery.noConflict();

    jQuery(document).ready(function ($) {
    var canvas = document.getElementById('chart');
    var ctx = canvas.getContext('2d');

        var data = {
            labels: ['En panne', 'Irréparable', 'Réparé'],
            datasets: [{
                label: 'Répartition des Pannes',
                data: [<?php echo $enPanne; ?>, <?php echo $irréparable; ?>, <?php echo $repare; ?>],
                backgroundColor: ['rgba(255, 99, 132, 0.7)', 'rgba(255, 205, 86, 0.7)', 'rgba(75, 192, 192, 0.7)'],
                borderColor: ['rgba(255, 99, 132, 1)', 'rgba(255, 205, 86, 1)', 'rgba(75, 192, 192, 1)'],
                borderWidth: 1
            }]
        };

        var options = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        };

        var myChart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });
    });

    </script>
</body>

</html>

<?php
session_start();

// Connexion à la base de données (à remplacer avec vos propres informations)
include('../connect/connect.php');

// Vérifier si l'ID de l'utilisateur est passé en paramètre
if (isset($_GET['id'])) {
    $id_intervention = $_GET['id'];
    try{
        // Vérifier si l'alerte a déjà été affichée
        if (!isset($_SESSION['confirmation_shown'])) 
        {
            // Afficher une alerte de confirmation avec JavaScript
            echo '<script>
                    var confirmation = confirm("Êtes-vous sûr de vouloir supprimer cet materiel?");
                    if (confirmation) {
                        window.location.href = "supprimer_intervention.php?id=' . $id_intervention . '&confirmed=1";
                    } else {
                        window.location.href = "index.php";
                    }
                </script>';

            // Marquer l'alerte comme affichée dans la session
            $_SESSION['confirmation_shown'] = true;

            exit();
        } else {
            // Supprimer l'alerte de la session
            unset($_SESSION['confirmation_shown']);

            // Vérifier si la confirmation a été reçue
            if (isset($_GET['confirmed']) && $_GET['confirmed'] == 1) {
                // Supprimer l'utilisateur
                $stmt = $pdo->prepare("DELETE FROM intervention WHERE ID_Intervention = ?");
                $stmt->execute([$id_intervention]);
                if($stmt){
                    echo "<script>alert('la suppression effectué avec succées');</script>";
                }
            }

            // Rediriger vers la page d'index après la suppression
            header("Refresh:0; url=index.php");
            exit();
        }
    }catch(PDOException $e){
    echo '<script>alert("Erreur lors de la suppression de l\'intervention: ' . $e->getMessage() . '");</script>';
    echo '<script>window.location.href = "index.php";</script>';
    exit();
}
} else {
    // Rediriger si l'ID de l'utilisateur n'est pas spécifié
    echo '<div class="alert alert-danger" role="alert">
            Erreur lors de la suppression !!.
          </div>';
    echo '<script>window.location.href = "index.php";</script>';
    exit();
}
?>

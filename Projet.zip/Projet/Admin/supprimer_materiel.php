<?php
session_start();

// Connexion à la base de données (à remplacer avec vos propres informations)
include('../connect/connect.php');

// Vérifier si l'ID de l'utilisateur est passé en paramètre
if (isset($_GET['id'])) {
    $id_materiel = $_GET['id'];

    // Vérifier si l'alerte a déjà été affichée
    try{
        if (!isset($_SESSION['confirmation_shown'])) {
            // Afficher une alerte de confirmation avec JavaScript
            echo '<script>
                    var confirmation = confirm("Êtes-vous sûr de vouloir supprimer cet materiel?");
                    if (confirmation) {
                        window.location.href = "supprimer_materiel.php?id=' . $id_materiel . '&confirmed=1";
                    } else {
                        window.location.href = "index.php";
                    }
                  </script>';
    
            // Marquer l'alerte comme affichée dans la session
            $_SESSION['confirmation_shown'] = true;
    
            exit();
        } else {
            // Supprimer l'alerte de la session
            unset($_SESSION['confirmation_shown']);
    
            // Vérifier si la confirmation a été reçue
            if (isset($_GET['confirmed']) && $_GET['confirmed'] == 1) {
                // Supprimer l'utilisateur
                $stmt = $pdo->prepare("DELETE FROM materiel WHERE ID_Materiel = ?");
                $stmt->execute([$id_materiel]);
            }
    
            // Rediriger vers la page d'index après la suppression
            header("Location: index.php");
            exit();
        }
    }catch(PDOException $e){
        echo '<script>alert("Erreur lors de la suppression du matériel: ' . $e->getMessage() . '");</script>';
        echo '<script>window.location.href = "index.php";</script>';
        exit();
    }
} else {
    // Rediriger si l'ID de l'utilisateur n'est pas spécifié
    echo '<div class="alert alert-danger" role="alert">
            Erreur lors de la suppression !!.
          </div>';
    echo '<script>window.location.href = "index.php";</script>';
    exit();
}
?>

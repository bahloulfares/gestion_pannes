<?php
// Vérifier si le formulaire a été soumis
if (isset($_POST['valider'])) {
    // Connexion à la base de données (à remplacer avec vos propres informations)
    include('../connect/connect.php');

    // Récupérer les données du formulaire
    $produit = $_POST['produit'];
    $Marque = $_POST['Marque'];
    $model = $_POST['model'];
    $NumSerie = $_POST['NumSerie'];
    $DateMES = $_POST['DateMES'];
    $Service = $_POST['Service'];
    $Statut = $_POST['Statut'];
    $id_utilisateur = $_POST['ID_Utilisateur'];

    // Préparer la requête d'insertion
    $stmt = $pdo->prepare("INSERT INTO materiel (produit, marque, model, NumSerie, DateMES, service, statut, id_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    // Exécuter la requête avec les valeurs fournies
    $stmt->execute([$produit, $Marque, $model, $NumSerie, $DateMES, $Service, $Statut, $id_utilisateur]);

    // Rediriger vers la liste des utilisateurs après l'ajout
    echo "<script>alert('le materiel a été ajoutée avec succès');</script>";
    header("refresh: 0");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter Materiel</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
   <center> <h2>Ajouter Materiel</h2></center>

    <form method="post" action="" autocomplete="off">
        <div class="form-group">
            <label for="produit">Produit:</label>
            <input type="text" class="form-control" id="produit" name="produit" required>
        </div>
        <div class="form-group">
            <label for="prenom">Marque:</label>
            <input type="text" class="form-control" id="prenom" name="Marque" required>
        </div>
        <div class="form-group">
            <label for="numTel">Model:</label>
            <input type="text" class="form-control" id="numTel" name="model" required>
        </div>
        <div class="form-group">
            <label for="role">Numero de serie:</label>
            <input type="number" class="form-control" id="role" name="NumSerie" required>
        </div>
        <div class="form-group">
            <label for="DateMES">Date mise en service:</label>
            <input type="date" class="form-control" id="DateMES" name="DateMES" required>
        </div>
        <div class="form-group">
            <label for="password">Service:</label>
            <input type="text" class="form-control" id="mdp" name="Service" required>
        </div>
        <div class="form-group">
                <label for="Statut">Statut</label>
                <select class="form-control" id="Statut" name="Statut" required>
                    <option value="En marche">En marche</option>
                </select>
            </div>
        <div class="form-group">
            <label for="Statut">ID Utilisateur</label>
            <input type="number" class="form-control" id="ID_Utilisateur" name="ID_Utilisateur" required>
        </div>
        <button type="submit" name="valider" class="btn btn-primary">Ajouter</button>
        <a href="index.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

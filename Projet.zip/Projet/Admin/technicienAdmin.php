<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Ajouter une demande</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script>
$(document).ready(function() {
    $('#recherche').on('click', function(e) {
        e.preventDefault();
        var serieMachine = $('#numero-demande').val();

        $.ajax({
            type: 'POST',
            url: 'search.php',
            data: { SM: serieMachine },
            success: function(response) {
                $('#resultat-recherche').html(response);

                // Récupérer les valeurs des champs cachés et les définir dans le formulaire
                var idUtilisateur = $('input[name="idUtilisateur"]').val();
                var idMateriel = $('input[name="idMateriel"]').val();

                // Afficher les valeurs récupérées (pour débogage)
                console.log('idUtilisateur:', idUtilisateur);
                console.log('idMateriel:', idMateriel);

                // Mettre à jour les valeurs des champs cachés dans le formulaire
                $('input[name="idUtilisateur"]').val(idUtilisateur);
                $('input[name="idMateriel"]').val(idMateriel);
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
            }
        });
    });

    $('#intervention-form').on('submit', function(e) {
        e.preventDefault(); // Empêche le rechargement de la page lors de la soumission du formulaire
        var formData = $(this).serialize();

        $.ajax({
            type: 'POST',
            url: 'validation.php',
            data: formData,
            success: function(response) {
                alert(response); // Afficher la réponse pour le débogage
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
            }
        });
    });
});
</script>

</head>
<body>
  <div style="width:900px;margin-left:280px;">
    <center> <h1>Ajouter Intervention</h1></center>
    <form action="validation.php" method="post" >
      <div class="form-group">
        <b><label for="numero-demande">Serie Materiel</label></b>
        <input type="number" name="SM" id="numero-demande" class="form-control">
        <button type="submit" name="recherche" id="recherche" class="btn btn-primary btn-sm">Recherche</button><br>
      </div>
      <div id="resultat-recherche"></div>
      <br>

      <div class="form-group">
        <b><label for="status">Statut du matériel</label></b>
        <select name="status" id="status" class="form-control">
          <option value="En cours de réparation">En cours de réparation</option>
        </select>
      </div>
      <div class="form-group">
        <b><label for="date-declaration">Date declaration</label></b><br>
        <input type="date" name="dd" id="dd" class="form-control" require>
      </div>
      <div class="form-group">
        <b><label for="date-declaration">description</label></b>
        <input type="text" name="desc" id="desc" class="form-control" require>
      </div><br>
      <button type="submit" name="valider" class="btn btn-primary" id="intervention-form">Valider</button>
      <a href="index.php" class="btn btn-secondary">Annuler</a>
      <br>
      <!-- Ajout des champs ID_Utilisateur et ID_Materiel -->
    </form>
  </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <title>Affichage du tableau ordretravail</title>
</head>

<body>

    <div class="container mt-5" Style="margin-left:70px;">

        <?php
        // Connexion à la base de données
        include('../connect/connect.php');

        // Récupérer les données de la table ordretravail avec la jointure sur la table utilisateur
        $sql = "SELECT OT.*, U.nom FROM ordretravail OT
                JOIN utilisateur U ON OT.ID_Utilisateur = U.ID_Utilisateur";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID_OT</th>
                    <th>DateDebut_OT</th>
                    <th>DateDeCloture</th>
                    <th>DateReparation</th>
                    <th>NatureTravaux</th>
                    <th>Observation</th>
                    <th>ID_Materiel</th>
                    <th>ID_Intervention</th>
                    <th>ID_Utilisateur</th>
                    <th>Nom</th>
                    <th>Action</th> <!-- New column for deletion button -->
                </tr>
            </thead>
            <tbody>

                <?php

                // Afficher les données
                if ($result) {
                    foreach ($result as $row) {
                        echo '<tr>';
                        echo '<td>' . $row['ID_OT'] . '</td>';
                        echo '<td>' . $row['DateDebut_OT'] . '</td>';
                        echo '<td>' . $row['DateDeCloture'] . '</td>';
                        echo '<td>' . $row['DateReparation'] . '</td>';
                        echo '<td>' . $row['NatureTravaux'] . '</td>';
                        echo '<td>' . $row['Observation'] . '</td>';
                        echo '<td>' . $row['ID_Materiel'] . '</td>';
                        echo '<td>' . $row['ID_Intervention'] . '</td>';
                        echo '<td>' . $row['ID_Utilisateur'] . '</td>';
                        echo '<td>' . $row['nom'] . '</td>';
                        echo '<td><a href="supprimer_historique.php?id=' . $row['ID_OT'] . '" class="btn btn-danger">Supprimer</a></td>'; // Deletion button
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="11" class="text-center">Aucune donnée trouvée dans la table ordretravail.</td></tr>';
                }
                ?>

            </tbody>
        </table>

        <?php
        // Fermer la connexion à la base de données
        $pdo = null;
        ?>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>

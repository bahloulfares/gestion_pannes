<?php
session_start();

// Connexion à la base de données (à remplacer avec vos propres informations)
include('../connect/connect.php');

// Vérifier si l'ID est passé en paramètre
if (isset($_GET['id'])) {
    $id_ot = $_GET['id'];

    // Vérifier si l'alerte a déjà été affichée
    if (!isset($_SESSION['confirmation_shown'])) {
        // Afficher une alerte de confirmation avec JavaScript
        echo '<script>
                var confirmation = confirm("Êtes-vous sûr de vouloir supprimer cette reparation?");
                if (confirmation) {
                    window.location.href = "supprimer_historique.php?id=' . $id_ot . '&confirmed=1";
                } else {
                    window.location.href = "index.php";
                }
              </script>';

        // Marquer l'alerte comme affichée dans la session
        $_SESSION['confirmation_shown'] = true;

        exit();
    } else {
        // Supprimer l'alerte de la session
        unset($_SESSION['confirmation_shown']);

        // Vérifier si la confirmation a été reçue
        if (isset($_GET['confirmed']) && $_GET['confirmed'] == 1) {
            // Supprimer l'utilisateur
            $stmtUpdateMateriel = $pdo->prepare("UPDATE materiel SET Statut = 'En cours de réparation' WHERE ID_Materiel = (SELECT ID_Materiel FROM ordretravail WHERE ID_OT = ?)");
            $stmtUpdateMateriel->execute([$id_ot]);
            
            $stmt = $pdo->prepare("DELETE FROM ordretravail WHERE ID_OT = ?");
            $stmt->execute([$id_ot]);

            if ($stmtUpdateMateriel) {
                echo "<script>alert('La suppression a été effectuée avec succès et le statut du matériel a été mis à jour.');</script>";
            }
        }

        // Rediriger vers la page d'index après la suppression
        header("Refresh:0; url=index.php");
        exit();
    }
} else {
    // Rediriger si l'ID de l'utilisateur n'est pas spécifié
    echo '<div class="alert alert-danger" role="alert">
            Erreur lors de la suppression !!.
          </div>';
    echo '<script>window.location.href = "index.php";</script>';
    exit();
}
?>

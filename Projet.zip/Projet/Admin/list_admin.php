<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des administrateur</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <center><h2>Liste des administrateur</h2></center><br><br>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Numéro de Téléphone</th>
                <th>Rôle</th>
                <th>Email</th>
                <th>Mot de passe</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Connexion à la base de données (à remplacer avec vos propres informations)
            include('../connect/connect.php');
            
            // Requête pour récupérer les utilisateurs
            $result = $pdo->query("SELECT * FROM admin");

            // Afficher les utilisateurs dans le tableau
            while ($admin = $result->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . $admin['ID_Admin'] . "</td>";
                echo "<td>" . $admin['nom'] . "</td>";
                echo "<td>" . $admin['prenom'] . "</td>";
                echo "<td>" . $admin['numTel'] . "</td>";
                echo "<td>" . $admin['role'] . "</td>";
                echo "<td>" . $admin['Email'] . "</td>";
                echo "<td>" . $admin['mdp'] . "</td>";
                echo '<td><a href="modifier_admin.php?id=' . $admin['ID_Admin'] . '" class="btn btn-primary btn-sm">Modifier</a></td>';
                echo '<td><a href="supprimer_admin.php?id=' . $admin['ID_Admin'] . '" class="btn btn-danger btn-sm">Supprimer</a></td>';
                echo "</tr>";
            }
            // Fermer la connexion à la base de données
            $pdo = null;
            ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="8" class="text-center">
                <a href="ajouter_admin.php" class="btn btn-success">Ajouter administrateur</a>
            </td>
        </tr>
        </tfoot>
    </table>
</div>

<!-- Ajoutez le lien vers le fichier JavaScript Bootstrap (optionnel) -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

<?php
session_start();
include "../connect/connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['valider'])) {
    try {

        if (!isset($_POST['idUtilisateur'], $_POST['idMateriel'], $_POST['dd'], $_POST['desc'], $_POST['status'])) {
            echo "<script>alert('Veuillez remplir tous les champs du formulaire !!');</script>";
            header("Refresh:0; url=index.php"); // Redirection vers la même page après 2 secondes
            exit();
        }

        $idUtilisateur = $_POST['idUtilisateur'];
        $idMateriel = $_POST['idMateriel'];
        $dateDeclaration = $_POST['dd'];
        $description = $_POST['desc'];
        $selectedStatus = $_POST['status'];

        $result = $pdo->query("SELECT * FROM materiel WHERE ID_Materiel = $idMateriel");
        $materiel = $result->fetch(PDO::FETCH_ASSOC);
        $sm = $materiel['Statut'];

        if($sm == "En cours de réparation"){
            echo "<script>alert('Erreur le materiel dega en cours de reparation.');</script>";
            header("Refresh:0; url=index.php");
            exit();
        }
        
        if (empty($idUtilisateur) || empty($idMateriel) || empty($dateDeclaration) || empty($description) || empty($selectedStatus)) {
            echo "<script>alert('Veuillez remplir tous les champs du formulaire!');</script>";
            header("Refresh:0; url=index.php"); // Redirection vers la même page après 2 secondes
            exit();
        }

        // Requête pour ajouter une intervention à la table Intervention
        $query = "INSERT INTO intervention (DateDeclaration, Description, ID_Utilisateur, ID_Materiel)
                    VALUES (:dateDeclaration, :description, :idUtilisateur, :idMateriel)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':dateDeclaration', $dateDeclaration, PDO::PARAM_STR);
        $stmt->bindParam(':description', $description, PDO::PARAM_STR);
        $stmt->bindParam(':idUtilisateur', $idUtilisateur, PDO::PARAM_INT);
        $stmt->bindParam(':idMateriel', $idMateriel, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt) {
            // Requête pour mettre à jour le statut du matériel
            $updateQuery = "UPDATE materiel SET Statut = :status WHERE ID_Materiel = :idMateriel";
            $updateStmt = $pdo->prepare($updateQuery);
            $updateStmt->bindParam(':status', $selectedStatus, PDO::PARAM_STR);
            $updateStmt->bindParam(':idMateriel', $idMateriel, PDO::PARAM_INT);
            $updateStmt->execute();

            echo "<script>alert('L\'intervention a été ajoutée avec succès');</script>";
            header("Refresh:0; url=index.php");
        } else {
            echo "<script>alert('Erreur lors de l\'ajout de l\'intervention');</script>";
        }
    } catch (PDOException $e) {
        // En cas d'erreur PDO, affichez l'erreur
        echo "Erreur de connexion à la base de données: " . $e->getMessage();
    }
}
?>

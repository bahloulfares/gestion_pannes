<?php
session_start();
include "../connect/connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['SM'])) {
    $serieMachine = $_POST['SM'];
    $sql = "SELECT * FROM materiel WHERE NumSerie = :SM";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':SM', $serieMachine);

    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // Display the details in a Bootstrap-styled table
        echo '<table class="table table-bordered">';
        echo '<thead class="thead-light">';
        echo '<tr>';
        echo '<th>ID_Materiel</th>';
        echo '<th>Produit</th>';
        echo '<th>Marque</th>';
        echo '<th>Model</th>';
        echo '<th>NumSerie</th>';
        echo '<th>DateMES</th>';
        echo '<th>Service</th>';
        echo '<th>Statut</th>';
        echo '<th>ID_Utilisateur</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        echo '<tr>';
        echo '<td>' . $result['ID_Materiel'] . '</td>';
        echo '<td>' . $result['Produit'] . '</td>';
        echo '<td>' . $result['Marque'] . '</td>';
        echo '<td>' . $result['model'] . '</td>';
        echo '<td>' . $result['NumSerie'] . '</td>';
        echo '<td>' . $result['DateMES'] . '</td>';
        echo '<td>' . $result['Service'] . '</td>';
        echo '<td>' . $result['Statut'] . '</td>';
        echo '<td>' . $result['ID_Utilisateur'] . '</td>';
        echo '</tr>';
        echo '</tbody>';
        echo '</table>';

        // Include hidden input fields inside the resultat-recherche div
        echo '<div id="resultat-recherche">';
        echo '<input type="hidden" name="idMateriel" value="' . $result['ID_Materiel'] . '">';
        echo '<input type="hidden" name="idUtilisateur" value="' . $result['ID_Utilisateur'] . '">';
        echo '</div>';
    } else {
        echo '<span style="color: red; font-weight: bold;">Matériel non trouvé</span>';

    }
}
?>

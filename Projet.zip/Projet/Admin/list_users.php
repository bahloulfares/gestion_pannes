<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Utilisateurs</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
   <center> <h2>Liste des Utilisateurs</h2></center><br><br>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Numéro de Téléphone</th>
                <th>Rôle</th>
                <th>Email</th>
                <th>Mot de passe</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Connexion à la base de données (à remplacer avec vos propres informations)
            include('../connect/connect.php');
            
            // Requête pour récupérer les utilisateurs
            $result = $pdo->query("SELECT * FROM utilisateur");

            // Afficher les utilisateurs dans le tableau
            while ($utilisateur = $result->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . $utilisateur['ID_Utilisateur'] . "</td>";
                echo "<td>" . $utilisateur['nom'] . "</td>";
                echo "<td>" . $utilisateur['prenom'] . "</td>";
                echo "<td>" . $utilisateur['numTel'] . "</td>";
                echo "<td>" . $utilisateur['role'] . "</td>";
                echo "<td>" . $utilisateur['Email'] . "</td>";
                echo "<td>" . $utilisateur['mdp'] . "</td>";
                echo '<td><a href="modifier_utilisateur.php?id=' . $utilisateur['ID_Utilisateur'] . '" class="btn btn-primary btn-sm">Modifier</a></td>';
                echo '<td><a href="supprimer_utilisateur.php?id=' . $utilisateur['ID_Utilisateur'] . '" class="btn btn-danger btn-sm">Supprimer</a></td>';
                echo "</tr>";
            }

            // Fermer la connexion à la base de données
            $pdo = null;
            ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="8" class="text-center">
                <a href="ajouter_utilisateur.php" class="btn btn-success">Ajouter Utilisateur</a>
            </td>
        </tr>
        </tfoot>
    </table>
</div>

<!-- Ajoutez le lien vers le fichier JavaScript Bootstrap (optionnel) -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

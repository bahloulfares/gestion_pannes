<?php
// Connexion à la base de données (à remplacer avec vos propres informations)
include('../connect/connect.php');

// Vérifier si l'ID de l'utilisateur est passé en paramètre
if (isset($_GET['id'])) {
    $id_utilisateur = $_GET['id'];

    // Récupérer les informations de l'utilisateur
    $stmt = $pdo->prepare("SELECT * FROM materiel WHERE ID_Materiel = ?");
    $stmt->execute([$id_utilisateur]);
    $materiel = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$materiel) {
        // Rediriger si l'utilisateur n'est pas trouvé
        header("Location: index.php");
        exit();
    }
} else {
    // Rediriger si l'ID de l'utilisateur n'est pas spécifié
    header("Location: index.php");
    exit();
}

// Traitement du formulaire de modification si le formulaire est soumis
if (isset($_POST['confirm'])) {
    // Récupérer les données du formulaire
    $ID_Materiel = $_POST['ID_Materiel'];
    $produit = $_POST['produit'];
    $Marque = $_POST['Marque'];
    $model = $_POST['model'];
    $NumSerie = $_POST['NumSerie'];
    $DateMES = $_POST['DateMES'];
    $Service = $_POST['Service'];
    $Statut = $_POST['Statut'];
    $id_utilisateur = $_POST['ID_Utilisateur'];

    $stmt = $pdo->prepare("UPDATE materiel SET ID_Materiel=?, Produit=?, Marque=?, model=?, NumSerie=?, DateMES=?, Service=?, Statut=?, ID_Utilisateur=? WHERE ID_Materiel=?");
    $stmt->execute([$ID_Materiel, $produit, $Marque, $model, $NumSerie, $DateMES, $Service, $Statut, $id_utilisateur, $ID_Materiel]);

    // Rediriger après la modification
    if($stmt){
        echo "<script>alert('Modification effectué avec succées.');</script>";
    }
    header("Refresh:0; url=index.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier administrateur</title>
    <!-- Ajoutez les liens vers les fichiers CSS Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Modifier administrateur</h2>

    <form method="post" action="">
        <div class="form-group">
            <label for="ID_Materiel">ID Materiel:</label>
            <input type="number" class="form-control" id="ID_Materiel" name="ID_Materiel" value="<?php echo $materiel['ID_Materiel']; ?>">
        </div>
        <div class="form-group">
            <label for="Produit">Nom Produit:</label>
            <input type="text" class="form-control" id="Produit" name="produit" value="<?php echo $materiel['Produit']; ?>">
        </div>
        <div class="form-group">
            <label for="prenom">Marque:</label>
            <input type="text" class="form-control" id="prenom" name="Marque" value="<?php echo $materiel['Marque']; ?>">
        </div>
        <div class="form-group">
            <label for="numTel">Model:</label>
            <input type="text" class="form-control" id="numTel" name="model" value="<?php echo $materiel['model']; ?>">
        </div>
        <div class="form-group">
            <label for="role">Numero de serie:</label>
            <input type="number" class="form-control" id="role" name="NumSerie" value="<?php echo $materiel['NumSerie']; ?>">
        </div>
        <div class="form-group">
            <label for="DateMES">Date mise en service:</label>
            <input type="date" class="form-control" id="DateMES" name="DateMES" value="<?php echo $materiel['DateMES']; ?>">
        </div>
        <div class="form-group">
            <label for="password">Service:</label>
            <input type="text" class="form-control" id="mdp" name="Service" value="<?php echo $materiel['Service']; ?>">
        </div>
        <div class="form-group">
            <label for="Statut">Statut</label>
            <input type="text" class="form-control" id="Statut" name="Statut" value="<?php echo $materiel['Statut']; ?>">
        </div>
        <div class="form-group">
            <label for="Statut">ID Utilisateur</label>
            <input type="number" class="form-control" id="ID_Utilisateur" name="ID_Utilisateur" value="<?php echo $materiel['ID_Utilisateur']; ?>">
        </div>
        <button type="submit" name="confirm"class="btn btn-primary">Enregistrer les modifications</button>
        <a href="index.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>

<!-- Ajoutez le lien vers le fichier JavaScript Bootstrap (optionnel) -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>
